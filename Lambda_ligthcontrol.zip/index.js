var APP_ID = "amzn1.ask.skill.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"; // input the axela skill ID
var AWS = require('aws-sdk');
var Alexa = require("alexa-sdk");

AWS.config.region = "us-east-1";
var iotData = new AWS.IotData({endpoint: "xxxxxxxxxxxxxx.iot.us-east-1.amazonaws.com"}); // input the AWS thing end point
var topic = "Topic"; //input the topic that the device is subscribed to

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};



var handlers = {

	'LaunchRequest': function () {
        this.emit(':tell', 'Hello. How may I help you?');
   },

	
    'SwitchOnIntent': function () {
      var params = {
          topic: topic,
          payload: "on",
          qos:0
      };
      iotData.publish(params, (error, data)=>{
          if (!error){this.emit(':tell', 'Switched On');
              
          }else{this.emit(':tell', 'Something went wrong')}
        });

    },
    'SwitchOffIntent': function () {
      var params = {
          topic: topic,
          payload: "off",
          qos:0
      };
      iotData.publish(params, (error, data)=>{
          if (!error){this.emit(':tell', 'Switched Off');
              
          }else{this.emit(':tell', 'Something went wrong')}
        });

    },
    'Unhandled': function () {
        this.emit(':tell', 'sorry');
    }
};